let img;

function preload(){
img = loadImage('Movietheater.jpg');
}
let song;

function setup() {
  song= loadSound("scarletvowaviators.mp3")
}

function setup() {
  createCanvas(540,500);
}

function draw() {
  background(60,29,190);
 textSize(70);
  fill(222,0,0);
  text('Critical Lens', 60, 58);
  fill(78,56,87);
image(img, 70,100,400,300);
  textSize(40);
  fill(186,228,248)
  text("Episode 1: Introductions", 75,440)
  

  

  
 
       
  
  
  
}
